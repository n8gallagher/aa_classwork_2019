module Stepable

   def move_diffs
   end

    def moves
        all_moves = self.move_diffs
    end
end