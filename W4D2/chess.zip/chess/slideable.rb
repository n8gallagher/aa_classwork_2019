module Slideable
    
end